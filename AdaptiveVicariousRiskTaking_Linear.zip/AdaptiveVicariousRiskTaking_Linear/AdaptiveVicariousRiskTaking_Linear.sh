#!/bin/bash

module load afni/20.3.00 
module load r/3.6.0 

echo 'R_LIBS_USER="~/R/libs"' >  $HOME/.Renviron
export R_MAX_VSIZE=32000000000

3dLMEr -prefix 3dLMEr_pm_linear -jobs 28 \
 -model 'decision*grade_6+(1|Subj)' \
 -qVars "grade_6" \
 -qVarCenters "0" \
 -gltCode Uncertain_PM_BF 'decision : 1*unc_pm_bf' \
 -gltCode Uncertain_PM_Parent 'decision : 1*unc_pm_pa' \
 -gltCode Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_pm_bf -1*unc_pm_pa' \
 -gltCode grade_6.Uncertain_PM_BF  'decision : 1*unc_pm_bf grade_6 : ' \
 -gltCode grade_6.Uncertain_PM_Parent  'decision : 1*unc_pm_pa grade_6 : ' \
 -gltCode grade_6.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_pm_bf -1*unc_pm_pa grade_6 : ' \
 -gltCode grade6.Uncertain_PM_BF  'decision : 1*unc_pm_bf grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_BF  'decision : 1*unc_pm_bf grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_BF  'decision : 1*unc_pm_bf grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_BF  'decision : 1*unc_pm_bf grade_6 : 3' \
 -gltCode grade6.Uncertain_PM_Parent   'decision : 1*unc_pm_pa grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_Parent   'decision : 1*unc_pm_pa grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_Parent   'decision : 1*unc_pm_pa grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_Parent   'decision : 1*unc_pm_pa grade_6 : 3' \
 -gltCode grade6.Uncertain_PM_BF-Uncertain_PM_Parent   'decision : 1*unc_pm_bf -1*unc_pm_pa grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_BF-Uncertain_PM_Parent   'decision : 1*unc_pm_bf -1*unc_pm_pa grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_pm_bf -1*unc_pm_pa grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_pm_bf -1*unc_pm_pa grade_6 : 3' \
 -dataTable \
Subj decision grade_6 wave InputFile \
