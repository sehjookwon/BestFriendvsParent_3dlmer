#!/bin/bash

module load afni/20.3.00 
module load r/3.6.0 

echo 'R_LIBS_USER="~/R/libs"' >  $HOME/.Renviron
export R_MAX_VSIZE=32000000000

3dLMEr -prefix 3dLMEr_nopm_quad -jobs 28 \
 -model 'decision*grade_6+decision*grade_6_2+(1|Subj)' \
 -qVars "grade_6,grade_6_2" \
 -qVarCenters "0,0" \
 -gltCode Uncertain_PM_BF 'decision : 1*unc_bf' \
 -gltCode Uncertain_PM_Parent 'decision : 1*unc_pa' \
 -gltCode Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_bf -1*unc_pa' \
 -gltCode grade_6.Uncertain_PM_BF  'decision : 1*unc_bf grade_6 : ' \
 -gltCode grade_6.Uncertain_PM_Parent  'decision : 1*unc_pa grade_6 : ' \
 -gltCode grade_6.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_bf -1*unc_pa grade_6 : ' \
 -gltCode grade6.Uncertain_PM_BF  'decision : 1*unc_bf grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_BF  'decision : 1*unc_bf grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_BF  'decision : 1*unc_bf grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_BF  'decision : 1*unc_bf grade_6 : 3' \
 -gltCode grade6.Uncertain_PM_Parent   'decision : 1*unc_pa grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_Parent   'decision : 1*unc_pa grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_Parent   'decision : 1*unc_pa grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_Parent   'decision : 1*unc_pa grade_6 : 3' \
 -gltCode grade6.Uncertain_PM_BF-Uncertain_PM_Parent   'decision : 1*unc_bf -1*unc_pa grade_6 : 0' \
 -gltCode grade7.Uncertain_PM_BF-Uncertain_PM_Parent   'decision : 1*unc_bf -1*unc_pa grade_6 : 1' \
 -gltCode grade8.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_bf -1*unc_pa grade_6 : 2' \
 -gltCode grade9.Uncertain_PM_BF-Uncertain_PM_Parent  'decision : 1*unc_bf -1*unc_pa grade_6 : 3' \
 -gltCode grade_6_2.Uncertain_BF  'decision : 1*unc_bf grade_6_2 : ' \
 -gltCode grade_6_2.Uncertain_Parent  'decision : 1*unc_pa grade_6_2 : ' \
 -gltCode grade_6_2.Uncertain_BF-Uncertain_Parent  'decision : 1*unc_bf -1*unc_pa grade_6_2 : ' \
 -dataTable \
Subj decision grade_6 grade_6_2 wave InputFile \
